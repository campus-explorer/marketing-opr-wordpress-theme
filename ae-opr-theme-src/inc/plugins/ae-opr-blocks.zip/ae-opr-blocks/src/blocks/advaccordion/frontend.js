//This is the frontend scrtipts

const headers = document.querySelectorAll('.aeopr-accordion-header button');
console.log(headers,'headers')