/**
 * BLOCK: Menu Section - Attributes
 */

const attributes = {
	block_id:{
		type:"string"
	},
	area_name:{
		type:"string"
	},
	menuItems:{
		type:"object"
	}
}

export default attributes
