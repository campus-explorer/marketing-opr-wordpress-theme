/**
 * OPR Course Manager
 */
